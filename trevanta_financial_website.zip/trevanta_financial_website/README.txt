TREVANTA FINANCIAL SERVICES - STARTER WEBSITE

Files:
- index.html: complete responsive one-page website (HTML, CSS and JavaScript in one file)

How to preview:
1. Open index.html in Chrome, Edge, Safari or Firefox.
2. Edit the file in Visual Studio Code or another text editor.

Before publishing:
1. Confirm the business name and legal entity name.
2. Confirm the WhatsApp number in all occurrences of 919284900656.
3. Add official email, address, business hours and privacy policy.
4. Add real partner names/logos only where you have permission and an active relationship.
5. Review all regulatory permissions and required disclosures for Demat, loans, insurance, mutual funds and deposits.
6. The contact form currently opens WhatsApp; it does not save leads to a database.

Free hosting:
- Create a GitHub account at https://github.com/
- Create a public repository named trevanta-financial-services
- Upload index.html
- Open repository Settings > Pages
- Choose Deploy from a branch, select main and /(root), then Save.
- GitHub Pages will provide a free website URL.
