TREVANTA FINANCIAL SERVICES WEBSITE - LOAN PAGE UPDATE

Upload BOTH index.html and loans.html to the root of your GitHub repository.
The loan service links on the homepage open loans.html in a new browser tab.
The loan page includes loan categories, indicative eligibility, typical documents,
a sample lender directory, and a WhatsApp enquiry form.

The enquiry form opens WhatsApp and does not store data in a database.
Verify lender products, current criteria, authorizations and disclosures before publishing.
